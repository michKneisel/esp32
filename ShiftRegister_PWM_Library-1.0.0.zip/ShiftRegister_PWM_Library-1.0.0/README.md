# ShiftRegister-PWM-Library
The ShiftRegister PWM Library enables usage of shift register pins as pulse width modulated (PWM) pins. Instead of setting them to either high or low, the library lets the user set them to up to 256 PWM-levels.

## [Getting started](https://timodenk.com/blog/shiftregister-pwm-library)
This post serves as a documentation page for the library.